﻿namespace Calculate;

public class MainClass
{
    static void Main(string[] args)
    {
        Program program = new();
        Program.Run();
    }
}
